<!-- 
footer.php：フッター
Autor：豊島
Virsion：0.0.1
Crated：2021.05.19
Update：2021.05.20 
-->    
    
<footer class="pc">
        <nav class="nav">
                <ul>
                <li><a href="policy.php">プライバシーポリシー</a></li>
                <li><a href="service.php">利用規約</a></li>
                <li><a href="company.php">運営会社</a></li>
            </ul>
        </nav>
        <p id=footer_nav>Copyright © 株式会社システムリサーチ チーム乙女. All rights reserved.</p>
    </footer>
</body>
</html>